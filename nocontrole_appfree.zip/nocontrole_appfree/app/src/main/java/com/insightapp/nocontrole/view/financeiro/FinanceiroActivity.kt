package com.insightapp.nocontrole.view.financeiro

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.insightapp.nocontrole.R

class FinanceiroActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_financeiro)
    }
}
